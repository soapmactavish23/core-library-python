# Core Library Python

Lib comum Python da House Software.

## Criar ambiente virtual

```powershell
python -m venv .venv
````

## Ativar ambiente virtual

```powershell
.\.venv\Scripts\activate
```

## Instalar dependências

```powershell
pip install -r requirements.txt
```

## Instalar ferramentas de build

```powershell
pip install build twine
```

## Gerar pacote

```powershell
python -m build
```

## Publicar no Nexus

```powershell
python -m twine upload --repository-url https://nexus.house-software.com.br/repository/python-house-libs/ dist/*
```

## Instalar a lib pelo Nexus

```powershell
pip install core-library-python --index-url https://nexus.house-software.com.br/repository/python-house-libs/simple
```

## Usar no requirements.txt da API

```txt
--index-url https://nexus.house-software.com.br/repository/python-house-libs/simple

core-library-python==0.0.1
```
